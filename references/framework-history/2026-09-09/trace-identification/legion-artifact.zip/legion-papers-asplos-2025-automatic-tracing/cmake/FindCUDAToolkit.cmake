#------------------------------------------------------------------------------#
# Copyright 2024 Kitware, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#------------------------------------------------------------------------------#

# Use at least CMake v3.26's version of FindCUDAToolit.cmake
if(CMAKE_VERSION VERSION_LESS "3.26")
  include(${CMAKE_CURRENT_LIST_DIR}/newcmake/FindCUDAToolkit.cmake)
else()
  include(${CMAKE_ROOT}/Modules/FindCUDAToolkit.cmake)
endif()
