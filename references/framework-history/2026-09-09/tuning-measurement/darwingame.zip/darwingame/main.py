#!/usr/bin/env python3
import itertools
import random
import math
import statistics
from concurrent.futures import ThreadPoolExecutor, as_completed

from application_setup import get_search_space, execute_application

def generate_all_configurations(search_space):
    # Sort search_space
    sorted_params = sorted(search_space.items(), key=lambda x: x[0])
    keys = [k for (k, _) in sorted_params]
    value_lists = [v for (_, v) in sorted_params]
    # Cartesian product of all values
    all_combos = []
    for combo in itertools.product(*value_lists):
        param_dict = {}
        for i, param_name in enumerate(keys):
            param_dict[param_name] = combo[i]
        all_combos.append(param_dict)
    return all_combos

def chunk_into_regions(all_configurations, num_regions):
    random.shuffle(all_configurations)  ## shuffle for even distribution
    total = len(all_configurations)
    avg_size = total // num_regions
    regions = []
    start = 0
    for i in range(num_regions):
        # Last region takes leftover
        end = start + avg_size if i < num_regions - 1 else total
        region_configs = all_configurations[start:end]
        regions.append(region_configs)
        start = end
    return regions

def play_one_game(configs_in_game):
    # Run concurrently in ThreadPool
    results = {}
    def run_config(cfg):
        exec_time = execute_application(cfg)
        return (cfg, exec_time)
    with ThreadPoolExecutor(max_workers=len(configs_in_game)) as pool:
        future_map = {pool.submit(run_config, c): c for c in configs_in_game}
        for fut in as_completed(future_map):
            c = future_map[fut]
            cfg, exec_time = fut.result()
            results[tuple(cfg.items())] = exec_time
    return results

def select_next_game_players(never_played, players_per_game, played_config_probs):
    count_new = players_per_game // 2
    count_old = players_per_game - count_new
    chosen = []
    #Choose from never_played
    if len(never_played) >= count_new:
        chosen_new = random.sample(never_played, count_new)
    else:
        chosen_new = never_played.copy()
    # Remove from never_played
    for c in chosen_new:
        never_played.remove(c)
    chosen.extend(chosen_new)
    #Choose from previously played -- weighted by performance
    if len(played_config_probs) == 0:
        chosen_old = []
    else:
        configs_only = [x[0] for x in played_config_probs]
        probs_only = [x[1] for x in played_config_probs]
        chosen_old = random.choices(configs_only, weights=probs_only, k=count_old)
    chosen.extend(chosen_old)
    # In case there is duplication
    chosen = list({tuple(c.items()): c for c in chosen}.values())
    return chosen

def run_regional_tournament(region_id, region_configs,players_per_game=4,max_rounds=5,top_percentage=20.0):
    never_played = region_configs.copy()
    random.shuffle(never_played)
    # played_stats: { config_tuple: {"times_played": int, "total_time": float} }
    played_stats = {}
    current_round = 1
    while current_round <= max_rounds:
        print(f"[Region {region_id}] Starting Round {current_round} ...")
        # Probability distribution from old participants
        if played_stats:
            sum_invs = 0.0
            config_prob_list = []
            for ctuple, st in played_stats.items():
                avg_time = st["total_time"] / st["times_played"]
                inv = 1.0 / avg_time
                sum_invs += inv
                config_prob_list.append((ctuple, inv))
            played_config_probs = []
            if sum_invs > 0:
                for (ctuple, inv) in config_prob_list:
                    played_config_probs.append((dict(ctuple), inv / sum_invs))
            else:
                played_config_probs = []
        else:
            played_config_probs = []
        # Select players to be in the current game
        chosen_dicts = select_next_game_players(
            never_played=never_played,
            players_per_game=players_per_game,
            played_config_probs=played_config_probs
        )
        if not chosen_dicts:
            print(f"[Region {region_id}] No more players can be selected. Ending early.")
            break
        # Play the game
        game_results = play_one_game(chosen_dicts)
        # Update stats
        for ctuple, etime in game_results.items():
            if ctuple not in played_stats:
                played_stats[ctuple] = {"times_played": 0, "total_time": 0.0}
            played_stats[ctuple]["times_played"] += 1
            played_stats[ctuple]["total_time"] += etime
        current_round += 1
    # Compute average times for each config
    if not played_stats:
        return []  # No winners if region is empty or no one played
    config_avg_times = {}
    for ctuple, st in played_stats.items():
        avg_t = st["total_time"] / st["times_played"]
        config_avg_times[ctuple] = avg_t
    # Find the best average time
    best_config_tuple = min(config_avg_times, key=config_avg_times.get)
    best_avg_time = config_avg_times[best_config_tuple]
    threshold = best_avg_time * (1.0 + top_percentage / 100.0)
    # Identify winners
    winners_info = []
    for ctuple, avg_time in config_avg_times.items():
        if avg_time <= threshold:
            winners_info.append({
                "params": dict(ctuple),
                "avg_time": avg_time,
                "region": region_id
            })
    return winners_info

def main_regional_phase():
    # ---------------- Configurable parameters of the regional phase----------------
    num_regions = 100               # How many total regions
    max_parallel_regions = 2        # How many regions can run concurrently in parallel
    players_per_game = 4            # How many configurations are co-located in each game
    max_rounds_in_region = 5        # Maximum number of rounds for each region
    top_percentage = 20.0           # Top performers are chosen as winners if avg_time <= best*(1 + top_percentage/100)
    # ------------------------------------------------------------------------------- 
    # Get the full search space
    search_space = get_search_space()
    # Generate all parameter combinations
    print("Generating all parameter configurations...")
    all_configs = generate_all_configurations(search_space)
    print(f"Total number of possible configurations = {len(all_configs)}")
    # Divide them into multiple regions
    regions = chunk_into_regions(all_configs, num_regions=num_regions)
    for i, region_list in enumerate(regions):
        print(f"Region {i} has {len(region_list)} configurations.")
    print("\n===== Starting Regional Phase =====")
    region_winners_all = []  # accumulates winners across all regions
    def process_region(idx, configs):
        print(f">>> Processing Region {idx} with {len(configs)} configs.")
        winners_info = run_regional_tournament(
            region_id=idx,
            region_configs=configs,
            players_per_game=players_per_game,
            max_rounds=max_rounds_in_region,
            top_percentage=top_percentage
        )
        return (idx, winners_info)
    # Run the regional phase in parallel across 'max_parallel_regions'
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=max_parallel_regions) as pool:
        futures = []
        for i, region_configs in enumerate(regions):
            if not region_configs:
                continue  # skip empty region
            fut = pool.submit(process_region, i, region_configs)
            futures.append(fut)
        for fut in as_completed(futures):
            idx, winners_info = fut.result()
            region_winners_all.extend(winners_info)
            print(f"Region {idx} finished. Found {len(winners_info)} winner(s).")
    print("===== Regional Phase Completed =====")
    print(f"Total # of 'regional winners' across all regions = {len(region_winners_all)}") 
    # Return the aggregated winners (params, avg_time, region)
    return region_winners_all

def main_global_phase(regional_winners):
    # -------------------- Configurable parameters of the global phase --------------------
    group_size = 8               # how many players per group in main bracket
    max_parallel_groups = 2      # how many groups can run in parallel
    top_percentage = 20.0        # top X% (by combined score) advance each round
    narrow_fraction = 0.10       # when main bracket <= 10% of initial, do final single match
    max_global_rounds = 5        # maximum number of main bracket rounds allowed
    # -----------------------------------------------------------------
    # Initialize the main bracket
    main_bracket = []
    for winner in regional_winners:
        player = {
            "params": winner["params"],
            "total_time": 0.0,
            "times_played": 0,
            "consistency_sum": 0.0,
            "avg_time": winner["avg_time"],  # from regional phase
            "region": winner["region"],
        }
        main_bracket.append(player)
    loser_bracket = []  # Start empty
    def play_global_game(players_in_group):
        local_results = []
        def run_config(player_obj):
            etime = execute_application(player_obj["params"])
            return (player_obj, etime)
        with ThreadPoolExecutor(max_workers=len(players_in_group)) as pool:
            future_map = {pool.submit(run_config, p): p for p in players_in_group}
            for fut in as_completed(future_map):
                p_obj, etime = fut.result()
                local_results.append((p_obj, etime))
        # Sort ascending by etime
        local_results.sort(key=lambda x: x[1])
        # Update stats
        for rank, (plyr, ex_time) in enumerate(local_results, start=1):
            plyr["total_time"] += ex_time
            plyr["times_played"] += 1
            plyr["consistency_sum"] += (1.0 / rank)
            plyr["avg_time"] = plyr["total_time"] / plyr["times_played"]
        # Return sorted list of player objects
        sorted_players = [x[0] for x in local_results]
        return sorted_players
    def form_groups(players, size):
        random.shuffle(players)
        groups = []
        temp = players[:]
        while temp:
            group = []
            used_regions = set()
            idx = 0
            while idx < len(temp) and len(group) < size:
                candidate = temp[idx]
                if candidate["region"] not in used_regions:
                    group.append(candidate)
                    used_regions.add(candidate["region"])
                    temp.pop(idx)
                else:
                    idx += 1
            while len(group) < size and temp:
                group.append(temp.pop(0))
            groups.append(group)
        return groups
    def combined_score(player):
        if player["times_played"] > 0:
            consistency = player["consistency_sum"] / player["times_played"]
        else:
            consistency = 0.0
        return player["avg_time"] - consistency
    def pick_winners_and_losers(sorted_players):
        sc_list = [(plyr, combined_score(plyr)) for plyr in sorted_players]
        sc_list.sort(key=lambda x: x[1])  
        best_score = sc_list[0][1]
        threshold = best_score * (1.0 + top_percentage / 100.0)
        winners = []
        losers = []
        for (plyr, sc) in sc_list:
            if sc <= threshold:
                winners.append(plyr)
            else:
                losers.append(plyr)
        return winners, losers
    # Multiple rounds until main bracket is small enough or we hit max_global_rounds
    initial_count = len(main_bracket)
    round_count = 0
    while True:
        round_count += 1
        current_size = len(main_bracket)
        # Stop if bracket is small enough or we have reached max_global_rounds
        if current_size <= math.ceil(narrow_fraction * initial_count) or round_count > max_global_rounds:
            break
        # Form groups
        groups = form_groups(main_bracket, group_size)
        next_round_main = []
        # Each group in parallel
        with ThreadPoolExecutor(max_workers=max_parallel_groups) as pool:
            fut_map = {pool.submit(play_global_game, g): g for g in groups if g}
            for fut in as_completed(fut_map):
                sorted_pls = fut.result()
                winners, losers_ = pick_winners_and_losers(sorted_pls)
                next_round_main.extend(winners)
                loser_bracket.extend(losers_)
        main_bracket = next_round_main
        if not main_bracket:
            break
    # Final single game in main bracket (if there are any players left)
    if len(main_bracket) > 0:
        final_sorted = play_global_game(main_bracket)
        final_winners, final_losers = pick_winners_and_losers(final_sorted)
        final_winners = final_winners[:3]
        loser_bracket.extend(final_losers)
    else:
        final_winners = []  # No one left in main bracket
    if len(final_winners) < 3 and len(loser_bracket) > 0:
        union_players = final_winners + loser_bracket
        sc_list = [(p, combined_score(p)) for p in union_players]
        sc_list.sort(key=lambda x: x[1])  
        needed = 3 - len(final_winners)
        extended = []
        used_ids = set(id(x) for x in final_winners)  
        for (p, sc) in sc_list:
            if id(p) in used_ids:
                continue
            extended.append(p)
            if len(extended) >= needed:
                break
        final_winners.extend(extended)
        for p in extended:
            if p in loser_bracket:
                loser_bracket.remove(p)
    final_winners = final_winners[:3]
    # Wildcard from loser bracket
    wildcard_winner = None
    if loser_bracket:
        def weight_by_time(p):
            return 1.0 / max(p["avg_time"], 1e-8)
        if len(loser_bracket) <= group_size:
            chosen_losers = loser_bracket
        else:
            chosen_losers = random.choices(
                population=loser_bracket,
                weights=[weight_by_time(x) for x in loser_bracket],
                k=group_size
            )
        sorted_lb = play_global_game(chosen_losers)
        lwinners, llosers_ = pick_winners_and_losers(sorted_lb)
        if len(lwinners) > 0:
            wildcard_winner = lwinners[0]
    final_global_winners = []
    for w in final_winners:
        final_global_winners.append({
            "params": w["params"],
            "avg_time": w["avg_time"]
        })
    if wildcard_winner:
        final_global_winners.append({
            "params": wildcard_winner["params"],
            "avg_time": wildcard_winner["avg_time"]
        })
    final_global_winners = final_global_winners[:4]
    return final_global_winners

def run_2player_game(playerA, playerB):
    print(f"\n--- 2-Player Game ---") 
    print("Running config for player A:")
    timeA = execute_application(playerA["params"])
    print(f"Execution time for A: {timeA:.4f}")
    print("Running config for player B:")
    timeB = execute_application(playerB["params"])
    print(f"Execution time for B: {timeB:.4f}")
    if timeA < timeB:
        winner, loser = playerA, playerB
    else:
        winner, loser = playerB, playerA
    return winner, loser, timeA, timeB

def main_playoff_phase(playoff_players):
    playoff_players = sorted(playoff_players, key=lambda x: x["avg_time"])
    if len(playoff_players) < 4:
        print("WARNING: Less than 4 players in playoffs -- Adapting logic.")
    top_half = playoff_players[:2]
    bottom_half = playoff_players[2:]
    print("\n=== Playoffs Game #1 (Top 2) ===")
    winner1, loser1, _, _ = run_2player_game(top_half[0], top_half[1])
    print(f"Game #1 Winner: {winner1['params']}")  
    if len(bottom_half) < 2:
        print("\n=== Not enough players for a second match in the bottom half. ===")
        if len(bottom_half) == 1:
            winner2 = bottom_half[0]
            loser2 = loser1  
        else:
            winner2 = loser1
    else:
        print("\n=== Playoffs Game #2 (Bottom 2) ===")
        winner2, loser2, _, _ = run_2player_game(bottom_half[0], bottom_half[1])
        print(f"Game #2 Winner: {winner2['params']}")   
        print("\n=== Playoffs Game #3 (Loser of Game #1 vs Winner of Game #2) ===")
        winner3, loser3, _, _ = run_2player_game(loser1, winner2)
        print(f"Game #3 Winner: {winner3['params']}")
        finalist1 = winner1  # from game #1
        finalist2 = winner3  # from game #3
        return [finalist1, finalist2]
    best_two = playoff_players[:2]
    return best_two

def main_final(finalists):
    if len(finalists) < 2:
        print("WARNING: Only 1 or 0 finalist(s) found. The final match will be trivial.")
        if len(finalists) == 1:
            return finalists[0]  # automatically becomes the champion
        else:
            return None 
    print("\n=== DarwinGame Final ===")
    champ, runnerup, timeC, timeR = run_2player_game(finalists[0], finalists[1])
    print(f"\n--- Final Winner's config: {champ['params']}")
    print(f"--- Final Winner's measured time: {timeC if champ == finalists[0] else timeR:.4f}\n")
    return champ

if __name__ == "__main__":
    regional_winners = main_regional_phase()
    global_winners = main_global_phase(regional_winners)
    finalists = main_playoff_phase(global_winners)
    champion = main_final(finalists)
    print(f"*** DarwinGame Champion: {champion['params']} ***")