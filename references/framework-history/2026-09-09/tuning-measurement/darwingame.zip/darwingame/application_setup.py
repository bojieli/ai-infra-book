#!/usr/bin/env python3
import time
import random

def get_search_space():
    """
    Define the search space (parameters and their obtainable values) here
    """
    search_space = {
        "learning_rate": [0.001, 0.005, 0.01, 0.05, 0.1],
        "batch_size": [16, 32, 64, 128, 256],
        "num_layers": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "dropout": [0.0, 0.1, 0.3, 0.5, 0.7, 0.9],
        "activation_function": ["relu", "sigmoid", "tanh", "leaky_relu"],
        "optimizer": ["sgd", "adam", "rmsprop", "adagrad"],
        "use_batch_norm": [True, False],
    }
    return search_space

def execute_application(parameter_values):
    """
    Execute the application with the provided parameter values.
    """
    search_space = get_search_space()
    for param in parameter_values:
        if param not in search_space:
            raise ValueError(f"Error: Invalid parameter '{param}' provided. Allowed parameters: {list(search_space.keys())}")
    for param, value in parameter_values.items():
        if value not in search_space[param]:
            raise ValueError(f"Error: Invalid value '{value}' for parameter '{param}'. Allowed values: {search_space[param]}")
    print("Executing application with the following parameters:")
    for param, value in parameter_values.items():
        print(f"  {param}: {value}")

    start_time = time.time()
    
    # Replace the next two lines with invoking and executing the application with "parameter_values"
    workload = sum(float(value) for key, value in parameter_values.items() if isinstance(value, (int, float))) #replace with application invocation/execution command
    time.sleep(random.uniform(1,5)) #replace with application invocation/execution command

    end_time = time.time()

    execution_time = end_time - start_time
    print(f"The execution time: {execution_time:.4f} seconds.")
    return execution_time
